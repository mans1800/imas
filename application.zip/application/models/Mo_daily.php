<?php

		include('da_daily.php');

		class Mo_daily extends Da_daily {

		}
		