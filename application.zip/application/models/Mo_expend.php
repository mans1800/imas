<?php

		include('da_expend.php');

		class Mo_expend extends Da_expend {

		}
		