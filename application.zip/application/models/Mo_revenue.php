<?php

		include('da_revenue.php');

		class Mo_revenue extends Da_revenue {

		}
		