<?php

		include('da_sumdata.php');

		class Mo_sumdata extends Da_sumdata {

		}
		