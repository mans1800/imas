<div class='small-box bg-<?php echo $color; ?>'>
	<div class='inner'>
		<h3><?php echo $number; ?></h3>
		<p><?php echo $label; ?></p>
	</div>
	<div class='icon'>
		<i class='<?php echo $icon; ?>'></i>
	</div>
	<a href='<?php echo $url; ?>' class='small-box-footer'><?php echo $more_info; ?></a>
</div>