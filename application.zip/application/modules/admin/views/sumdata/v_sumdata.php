
<div class="row">
	<div class="col-md-12">
		<div class="box box-primary">
			<div class="box-header">
                            <h3 class="box-title">
                        <a href="<?php echo base_url(); ?>admin/sumdata/create" class="btn btn-info">
                        <i  class="fa fa-pencil-square-o fa-lg" aria-hidden="true"></i> <?php echo 'เพิ่มข้อมูล';?>
                    </a> 
                            </h3>
			</div>
			<div class="box-body">
				<table class="table table-striped table-bordered" cellspacing="0" width="100%">
					<thead>
						<tr>
							
							<th></th>
							
							<th></th>
							
							<th></th>
							
                                                        <th><center>เดบิต</center></th>
							
							<th><center>เครดิต</center></th>
							
						
						</tr>
					</thead>
					<tbody>
					<?PHP
						//foreach($data_cat as $row){
					?>
						<tr>
						
							
                                                    <td>ธนาคาร</td>
                                                    <td>ย.1.2</td>
                                                    <td><center>(111,092.25)</center></td>
                                                    <td><center>3,076,535.79</center></td>
                                                    <td></td>
                                                    </tr><tr>
                                                    <td>เงินสด</td>
                                                    <td>ย.1.1</td>
                                                    <td></td>
                                                    <td><center>111,092.25</center></td>
                                                    <td></td>
                                                    </tr><tr>
                                                    <td>เงินรับมัดจำ</td>
                                                    <td>ย.2.11</td>
                                                    <td></td>
                                                    <td></td>
                                                    <td><center>(3,189,867.00)</center></td>
                                                    </tr><tr>
                                                    <td>เงินยืมทดรองเรือ</td>
                                                    <td>ย.1.5</td>
                                                    <td></td>
                                                    <td></td>
                                                    <td><center>(0.01)</center></td>
                                                    </tr><tr>
                                                    <td>ค่าเสื่อมราคา คช</td>
                                                    <td>ย.5.7</td>
                                                    <td></td>
                                                    <td></td>
                                                    <td><center>465.53</center></td>
                                                    </tr><tr>
                                                    <td>สำรองราคา คช</td>
                                                    <td>ย 1.14</td>
                                                    <td></td>
                                                    <td></td>
                                                    <td><center>(465.53)</center></td>
                                                    </tr><tr>
                                                    <td>ภาษีซื้อ</td>
                                                    <td>ย 1.7</td>
                                                    <td></td>
                                                    <td></td>
                                                    <td><center>(657.93)</center></td>
                                                    </tr><tr>
                                                    <td>ภาษีซื้อค้างรับ</td>
                                                    <td>ย.1.9</td>
                                                    <td></td>
                                                    <td></td>
                                                    <td><center>(187.99)</center></td>
                                                    </tr><tr>
                                                    <td>ค่าธรรมเนียมธนาคาร</td>
                                                    <td>ย.5.13</td>
                                                    <td></td>
                                                    <td><center>2,238.96</center></td>
                                                    <td></td>
                                                    </tr><tr>
                                                    <td>ภาษีขาย</td>
                                                    <td>ย.2.9</td>
                                                    <td></td>
                                                    <td><center>10,843.00</center></td>
                                                    <td></td>
                                                    </tr><tr>
                                                    <td>คชจ.เบ็ดเตล็ด</td>
                                                    <td>ย.5.14</td>
                                                    <td></td>
                                                    <td><center>141.19</center></td>
                                                    <td></td>
                                                    </tr><tr>
                                                    <td>ภพ.30</td>
                                                    <td>ย.1.11</td>
                                                    <td></td>
                                                    <td></td>
                                                    <td><center>(9,997.09)</center></td>
							</tr><tr>
                                                    <td>เจ้าหนี้ ภงด. หัก ณ ที่จ่าย</td>
                                                    <td>ย.2.4</td>
                                                    <td></td>
                                                    <td></td>
                                                    <td><center>(141.17)</center></td>
                                                    </tr><tr>
                                                    <td>เจ้าหนี้ค่าระวาง</td>
                                                    <td>ย.2.1</td>
                                                    <td><center>7,700.00</center></td>
                                                    <td></td>
                                                    <td></td>
                                                    </tr><tr>
                                                    <td>ตท.ค่าขนส่ง</td>
                                                    <td>ย 3.4</td>
                                                    <td></td>
                                                    <td><center>64,603.24</center></td>
                                                    <td></td>
                                                    </tr><tr>
                                                    <td>เจ้าหนี้ค่าขนส่ง</td>
                                                    <td>ย.2.2</td>
                                                    <td></td>
                                                    <td></td>
                                                    <td><center>(64,603.24)</center></td>
                                                    </tr><tr>
                                                    <td>ตท.ค่าระวาง</td>
                                                    <td>ย.3.5</td>
                                                    <td></td>
                                                    <td></td>
                                                    <td><center>(7,700.00)</center></td>
                                                   </tr>
                                                   <tr><td></td><td></td><td></td><td><center><b>3,273,619.96</b></center></td><td><center><b>(3,273,619.96)</b></center></td></tr>
		
						
					<?PHP 
						//} 
					?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>